package com.example.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.sms.entity.Student;
import com.example.sms.repository.StudentRepository;

@SpringBootApplication
public class StudentMagmtSystemApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(StudentMagmtSystemApplication.class, args);
	}

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
//		Student s1 = new Student("Rup" ,"Dey","sma@gmail.com");
//		studentRepository.save(s1);
	}

}
